package com.toy4.jeommechu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeommechuApplication {

	public static void main(String[] args) {
		SpringApplication.run(JeommechuApplication.class, args);
	}

}
