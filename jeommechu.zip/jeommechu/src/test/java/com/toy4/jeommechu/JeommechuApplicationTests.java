package com.toy4.jeommechu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JeommechuApplicationTests {

	@Test
	void contextLoads() {
	}

}
